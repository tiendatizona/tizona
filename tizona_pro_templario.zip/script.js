document.querySelectorAll("button").forEach(btn=>{
btn.addEventListener("click",()=>{
alert("Producto añadido (demo)");
});
});
